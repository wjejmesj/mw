# Discord-Nitro-Proof-Bot

I made this quickly, after reading <a href="https://github.com/Snowwy1337/Discord-Nitro-Proof-Bot">Snowwy's NitroBot</a> and realised there wasn't one written in python, so here it is.



Simple to use, easy to setup
No proof bots made in python, so this is the first on github :)
Let me know if there are any issues/bugs with it, I will reply. Don't skid, leave creds...

Will be making more, for hypixel and roblox (possibly)

![capture](https://user-images.githubusercontent.com/118915559/203586598-c3442ffd-8d59-4c2d-8201-e8efa8ed7dfa.png)








How To Use

Right Click On main.py then Opem With Vscode and put Your Bot Token In The Front on tk=

![image](https://user-images.githubusercontent.com/118915559/203588860-8b736c96-8fd2-443c-b37b-517112e6fcf0.png)




You Need Python 3.9

Download The Code

Open Terminal||Console||CMD (in same folder)

python -m pip install discord --user

python main.py

python api.py

if It Shows Any Error then 


python -m pip install flask

python -m pip install bs4

python -m pip install playwright

python -m pip install pillow

python -m pip install requests




Command is !nitro <@username? <message>

  if You Guys Need Any Help Dm Me - Ashee#0001
